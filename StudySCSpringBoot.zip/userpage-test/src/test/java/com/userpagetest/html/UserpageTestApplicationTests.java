package com.userpagetest.html;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserpageTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
