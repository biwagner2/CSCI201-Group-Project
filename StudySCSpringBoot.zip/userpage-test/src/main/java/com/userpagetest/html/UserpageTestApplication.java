package com.userpagetest.html;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserpageTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserpageTestApplication.class, args);
	}

}
